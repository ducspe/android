<?php	
	//This script has the purpose of reading a file on the server logs folder
	//After reading it echoes the string back
	//open the file with the passed path
	$path = $_POST['postpath'];	
	$handle = fopen("../server_android/logs/".$path, "r");	
	$result = "";		
	//if found read it
	if ($handle) {
		//read all lines and append them to the output string
		while (($line = fgets($handle)) !== false) {			
			$result .= $line;
	    	}
		//close file	
		fclose($handle);
	}		
	//echo json_encode($result, JSON_HEX_APOS);
	echo $result;
?>
