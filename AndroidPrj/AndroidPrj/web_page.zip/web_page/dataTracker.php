<?php
$html = <<<EOT
	<script src="sorttable.js"></script>
	<html>
		<table class="sortable" style="width:100%">
			<tr>
				<td><p><b>AppName</b></p></td>
				<td><p><b>#Users</b></p></td>
				<td><p><b>Wifi-<br>Active Hours <i>[h]</i></b></p></td>
				<td><p><b>Wifi-<br>Active <i>[mb]</i></b></p></td>
				<td><p><b>Wifi-<br>InActive Hours <i>[h]</i></b></p></td>
				<td><p><b>Wifi-<br>InActive <i>[mb]</i></b></p></td>
				<td><p><b>Cellular-<br>Active Hours <i>[h]</i></b></p></td>
				<td><p><b>Cellular-<br>Active <i>[mb]</i></b></p></td>
				<td><p><b>Cellular-<br>InActive Hours <i>[h]<i/></b></p></td>
				<td><p><b>Cellular-<br>InActive <i>[mb]<i/></b></p></td>
			</tr>
			<tr>
			</tr>
EOT;
$period = $_GET['period'];
$handle = fopen("../server_android/logs/".$period, "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
        $html .= "<tr>\n";
        $parts = split("===", $line);
	#print_r($parts);
        $html .= "<td>".$parts[0]."</td>\n";
	$html .= "<td>".$parts[1]."</td>\n";
	$html .= "<td>".number_format(($parts[2]+0)/3600.0,4,'.','')."</td>\n";
	$html .= "<td>".number_format(($parts[3]+0)/1024.0/1024.0,4,'.','')."</td>\n";
	$html .= "<td>".number_format(($parts[4]+0)/3600.0,4,'.','')."</td>\n";
	$html .= "<td>".number_format(($parts[5]+0)/1024.0/1024.0,4,'.','')."</td>\n";
	$html .= "<td>".number_format(($parts[6]+0)/3600.0,4,'.','')."</td>\n";
	$html .= "<td>".number_format(($parts[7]+0)/1024.0/1024.0,4,'.','')."</td>\n";
	$html .= "<td>".number_format(($parts[8]+0)/3600.0,4,'.','')."</td>\n";
        $html .= "<td>".number_format(($parts[9]+0)/1024.0/1024.0,4,'.','')."</td>\n";
        $html .= "</tr>\n";
    }
    fclose($handle);
}
$html .= "</table></html>";
echo $html;
