package com.example.dan.DataTrafficViewer;

import android.content.Context;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by niku on 12/16/15.
 */
public class DataHandler {

    private String absPath;

    //Set path for the files. It is the path of the App installation on the phone
    public DataHandler(Context context) {
        this.absPath = context.getFilesDir().getAbsolutePath()+"/";
    }

    //write the passed string to the file
    public void writeToFile(String fileName, String content) {
        BufferedWriter bw = null;
        try {
            //Create the file object with the passed path
            File file = new File(this.absPath+fileName);

            //Create the file if it doesn't exist
            if (!file.exists()) {
                file.createNewFile();
            }
            //write the string to the file
            FileWriter fw = new FileWriter(file);
            bw = new BufferedWriter(fw);
            bw.write(content);
        } catch (IOException ioe) { }
        //Regardless of what happened close oll objects
        finally {
            try { if(bw != null) bw.close();} catch (Exception ex){ }
        }
    }

    //read the desired file and return its content in form of a string
    public String readFromFile(String fileName) {
        String content = "";
        try {
            content = new ProcFile(this.absPath+fileName).content;
        } catch (IOException e) { }
        return content;
    }
}
