package com.example.dan.DataTrafficViewer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

/**
 * Created by Cristi on 18.12.2015.
 This class is reponsible for getting the attributes of each application which will be sent to Xml in order to display them in GUI.
 */

public class ParticularAppShow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_particular_app_show);
		
		//get the values from the activity in AllAppsActivity my using the method "getExtra()"
        
		String wifiActiveB = getIntent().getExtras().getString("wifiActiveB");
        String wifiInactiveB = getIntent().getExtras().getString("wifiInactiveB");
        String cellularActiveB = getIntent().getExtras().getString("cellularActiveB");
        String cellularInactiveB = getIntent().getExtras().getString("cellularInactiveB");

        String wifiActiveTime = getIntent().getExtras().getString("wifiActiveTime");
        String wifiInactiveTime = getIntent().getExtras().getString("wifiInactiveTime");
        String cellularActiveTime = getIntent().getExtras().getString("cellularActiveTime");
        String cellularInactiveTime = getIntent().getExtras().getString("cellularInactiveTime");

        String AppName = getIntent().getExtras().getString("AppName");

		//create the view for the Xml
        TextView wifiActive = (TextView) findViewById(R.id.wifiActive);
        TextView wifiInactive = (TextView) findViewById(R.id.wifiInactive);
        TextView cellularActive = (TextView) findViewById(R.id.cellularActive);
        TextView cellularInactive = (TextView) findViewById(R.id.cellularInactive);

        TextView wifiActiveTimeShow = (TextView) findViewById(R.id.wifiActiveTimeShow);
        TextView wifiInactiveTimeShow = (TextView) findViewById(R.id.wifiInactiveTimeShow);
        TextView cellularActiveTimeShow = (TextView) findViewById(R.id.cellularActiveTimeShow);
        TextView cellularInactiveTimeShow = (TextView) findViewById(R.id.cellularInactiveTimeShow);

        TextView AppNameShow = (TextView) findViewById(R.id.AppNameShow);
		
		//set the values got from AllAppsActivity and sent them assign them for the Xml variables
        wifiActive.setText(wifiActiveB);
        wifiInactive.setText(wifiInactiveB);
        cellularActive.setText(cellularActiveB);
        cellularInactive.setText(cellularInactiveB);

        wifiActiveTimeShow.setText(wifiActiveTime);
        wifiInactiveTimeShow.setText(wifiInactiveTime);
        cellularActiveTimeShow.setText(cellularActiveTime);
        cellularInactiveTimeShow.setText(cellularInactiveTime);

        AppNameShow.setText(AppName);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_particular_app_show, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
