package com.example.dan.DataTrafficViewer;

/**
 * Created by Cristi on 18.12.2015.
 This class is reponsible for the main list view of the applications, displaying the icon, name and the total traffic per application
 */
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ApplicationAdapter extends ArrayAdapter<ApplicationInfo> {
    private List<ApplicationInfo> appsList = null;
    private Context context;
    protected PackageManager packageManager;
    private Intent myIntent;
    private String selection;

	//constructor
    public ApplicationAdapter(Context context, int textViewResourceId, List<ApplicationInfo> appsList, String selection) {
        super(context, textViewResourceId, appsList);
        this.context = context;
        this.appsList = appsList;
        packageManager = context.getPackageManager();
        this.selection = selection;
    }


    public Context sendBackContext(){
        return this.context;
    }
	//size of the list
    @Override
    public int getCount() {
        return ((null != appsList) ? appsList.size() : 0);
    }

    @Override
    public ApplicationInfo getItem(int position) {
        return ((null != appsList) ? appsList.get(position) : null);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
	//create the list and also calculate the total traffic for every application by reading the values from the files
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (null == view) {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.list_row, null);
        }

        ApplicationInfo data = appsList.get(position);

		//check only if data is not null, which means only when there is some application in the list, in case of no application the total traffic can not be calculated
        if (null != data) {
            TextView appName = (TextView) view.findViewById(R.id.app_name);
            TextView totalTraffic = (TextView) view.findViewById(R.id.totalTraffic);
            ImageView iconview = (ImageView) view.findViewById(R.id.app_icon);
            appName.setText(data.loadLabel(packageManager));

            MapHandler mapHandler = Controller.createMapHandlerFromFile(this.selection);
            mapHandler.mergeMap(Controller.getMapHandler().getMap(), true);
            //reading the values from the files stored from the mapHandler
			float calculateTotalTraffic = ((mapHandler.get(data.packageName).getWiFiActiveB() + mapHandler.get(data.packageName).getWiFiInactiveB() +
                    mapHandler.get(data.packageName).getCellularActiveB() + mapHandler.get(data.packageName).getCellularInactiveB())/1024.0f)/1024.0f;

            totalTraffic.setText(String.valueOf(String.format("%.2f",calculateTotalTraffic)));


            iconview.setImageDrawable(data.loadIcon(packageManager));
        }
        return view;
    }
};