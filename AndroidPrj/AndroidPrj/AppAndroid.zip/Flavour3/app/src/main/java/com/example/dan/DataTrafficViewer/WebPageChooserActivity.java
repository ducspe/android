package com.example.flavour1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.dan.DataTrafficViewer.R;
import com.example.dan.DataTrafficViewer.WebPageActivity;

public class WebPageChooserActivity extends AppCompatActivity {

    private TextView final_result;
    private Button startBrowser;
    private String url = "http://141.22.15.229/~w15cpteam3/dataTracker?period=2015/11";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_page_chooser);

        final_result = (TextView)findViewById(R.id.result_text);
        final_result.setEnabled(false);
/*
        startBrowser = (Button)findViewById(R.id.startBrowserBtn);
        startBrowser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), WebPageActivity.class);
                intent.putExtra("url_data", url);
                startActivity(intent);
            }
        });*/
    }


    public void selectUpdateURL(View view){
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()){

            case R.id.december:
                if(checked) {
                    url = "http://141.22.15.229/~w15cpteam3/dataTracker?period=2015/12";
                    final_result.setText("Show data for all users, for the entire month of december");
                    final_result.setEnabled(true);
                }else{
                    final_result.setEnabled(false);
                }
                break;
            case R.id.january:
                if(checked) {
                    url = "http://141.22.15.229/~w15cpteam3/dataTracker?period=2016/01";
                    final_result.setText("Show data for all users, for the entire month of january");
                    final_result.setEnabled(true);
                }else{
                    final_result.setEnabled(false);
                }
                break;
            case R.id.february:
                if(checked) {
                    url = "http://141.22.15.229/~w15cpteam3/dataTracker?period=2016/02";
                    final_result.setText("Show data for all users, for the entire month of february");
                    final_result.setEnabled(true);
                }else{
                    final_result.setEnabled(false);
                }
                break;
        }
    }

    public void openWebPage(View view) {
        Intent intent = new Intent(getBaseContext(), WebPageActivity.class);
        intent.putExtra("url_data", url);
        startActivity(intent);
    }
}
