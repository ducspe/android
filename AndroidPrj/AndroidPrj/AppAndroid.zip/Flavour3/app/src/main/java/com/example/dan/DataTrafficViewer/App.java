package com.example.dan.DataTrafficViewer;

import java.io.IOException;

/**
 * Created by niku on 12/10/15.
 */
public class App {
    private int uuid;
    private String name;
    private String packageName;
    private long WiFiActiveSeconds;
    private long WiFiActiveB;
    private long WiFiInactiveSeconds;
    private long WiFiInactiveB;
    private long CellularActiveSeconds;
    private long CellularActiveB;
    private long CellularInactiveSeconds;
    private long CellularInactiveB;
    private long initialB;
    private long startOfExecutionTime;
    private long startOfActiveTime;
    private long stopOfActiveTime;
    private long startOfActiveB;
    private long stopOfActiveB;
    private boolean isRunning;
    private boolean isActive;
    private boolean monthRunning;
    private boolean dayRunning;

    //default constructor
    public App() {
        this.setApp();
        dayRunning = true;
        monthRunning = true;
    }
    //constructor used to generate an APp object from the stored files
    public App(String appInStrForm) {
        this.setFromString(appInStrForm);
    }
    //constructor to generate an app when a new app is installed
    public App(int uuid, String name, String packageName) {
        this.setApp();
        this.uuid = uuid;
        this.packageName = packageName;
        this.name = name;
        dayRunning = true;
        monthRunning = true;
    }
    //function that sets the default values implicitly for the constructors above
    protected void setApp() {
        this.uuid = 0;
        this.packageName = "";
        this.name = "";
        this.resetApp();
    }

    protected void resetApp() {
        WiFiActiveSeconds = 0;
        WiFiActiveB = 0;
        WiFiInactiveSeconds = 0;
        WiFiInactiveB = 0;
        CellularActiveSeconds = 0;
        CellularActiveB = 0;
        CellularInactiveSeconds = 0;
        CellularInactiveB = 0;
        this.initialB = 0;
        //set initial total traffic, in order to be able to calculate the differential values
        this.initialB = this.getTotalTraffic();
    }

    protected long getTotalTraffic() {
        Long received = 0l;
        Long transmitted = 0l;
        try {
            //get transmitted/ received nr of bytes directly from the proc folder files
            received = Long.parseLong(new ProcFile("/proc/uid_stat/"+Integer.toString(this.uuid)+"/tcp_rcv").content);
            transmitted = Long.parseLong(new ProcFile("/proc/uid_stat/"+Integer.toString(this.uuid)+"/tcp_snd").content);
        } catch (IOException e) {
            return 0l;
        }
        //return the total traffic by deducting the total amount of bytes by the initial set value
        long temp = (received + transmitted) - this.initialB;
        if (temp < 0) {
            return 0l;
        } else {
            return temp;
        }
    }

    //update the inactive time of an app, according to the type of network used
    //Wifi:     2
    //Cellular: 1
    //None:     0
    public void updateInActiveTime(long time, int networkStatus){
        long temp;
        if (stopOfActiveTime != 0) { //if one of the networks is available
            if (networkStatus == 2) {//update wifi
                //update inactive stats by subtracting the total values by the values when the active time stopped
                temp = (time - stopOfActiveTime)/1000;
                if (temp < 0) temp = 0;
                this.WiFiInactiveSeconds += temp;
                temp = (this.getTotalTraffic() - this.stopOfActiveB);
                if (temp < 0) temp = 0;
                this.WiFiInactiveB += temp;
            } else if (networkStatus == 1) {//update cellular
                temp = (time - stopOfActiveTime)/1000;
                if (temp < 0) temp = 0;
                this.CellularInactiveSeconds += temp;
                temp = (this.getTotalTraffic() - this.stopOfActiveB);
                if (temp < 0) temp = 0;
                this.CellularInactiveB += temp;
            }
        }
    }
    //The calculation methodology is similar to the one for inactive time, only inverse
    public void updateActiveTime(long time, int networkStatus){
        long temp;
        if (startOfActiveTime != 0) {
            if (networkStatus == 2) {
                temp = (time - startOfActiveTime)/1000;
                if (temp < 0) temp = 0;
                this.WiFiActiveSeconds += temp;
                temp = (this.getTotalTraffic() - this.startOfActiveB);
                if (temp < 0) temp = 0;
                this.WiFiActiveB += temp;
            } else if (networkStatus == 1) {
                temp = (time - startOfActiveTime)/1000;
                if (temp < 0) temp = 0;
                this.CellularActiveSeconds += temp;
                temp = (this.getTotalTraffic() - this.startOfActiveB);
                if (temp < 0) temp = 0;
                this.CellularActiveB += temp;
            }
        }
    }
    //add the contents of the passed app to the current app
    protected void addApp(App app){
        this.WiFiActiveB += app.WiFiActiveB;
        this.WiFiActiveSeconds += app.WiFiActiveSeconds;
        this.WiFiInactiveB += app.WiFiInactiveB;
        this.WiFiInactiveSeconds += app.WiFiInactiveSeconds;
        this.CellularActiveB += app.CellularActiveB;
        this.CellularActiveSeconds += app.CellularActiveSeconds;
        this.CellularInactiveB += app.CellularInactiveB;
        this.CellularActiveSeconds += app.CellularActiveSeconds;
    }

    protected String getMeasurements() {
        String out = "";
        out += Long.toString(this.WiFiActiveSeconds) +
                Long.toString(this.WiFiActiveB) +
                Long.toString(this.WiFiInactiveSeconds) +
                Long.toString(this.WiFiInactiveB) +
                Long.toString(this.CellularActiveSeconds) +
                Long.toString(this.CellularActiveB) +
                Long.toString(this.CellularInactiveSeconds) +
                Long.toString(this.CellularInactiveB);
        return out;
    }
    //prepare string to be sent to the server. At this point it is important that the string
    //is formatted in the same manner as the server parser expects it.
    //Also since the Server measures all data in Hours and Megabytes the appropriate conversions
    //are necessary: Seconds to Hours, Bytes to MegaBytes
    public String toStringForServer(){
        String out = "";
        out +=  Boolean.toString(this.dayRunning) + "===" +
                Boolean.toString(this.monthRunning) + "===" +
                this.name + "===" +
                Long.toString(this.WiFiActiveSeconds) + "===" +
                Long.toString(this.WiFiActiveB) + "===" +
                Long.toString(this.WiFiInactiveSeconds) + "===" +
                Long.toString(this.WiFiInactiveB) + "===" +
                Long.toString(this.CellularActiveSeconds) + "===" +
                Long.toString(this.CellularActiveB) + "===" +
                Long.toString(this.CellularInactiveSeconds) + "===" +
                Long.toString(this.CellularInactiveB);
        return out;
    }
    //The dafault toString method. This saves all parameters of an app
    //The parameters are saved in the original unit of measure
    //It is used when the a backup of all apps is made on the clients phone
    @Override
    public String toString(){
        String out = "";
        out +=  this.packageName + "=" +
                this.name + "=" +
                Integer.toString(this.uuid) + "=" +
                Boolean.toString(this.monthRunning) + "=" +
                Boolean.toString(this.dayRunning) + "=" +
                Long.toString(this.WiFiActiveSeconds) + "=" +
                Long.toString(this.WiFiActiveB) + "=" +
                Long.toString(this.WiFiInactiveSeconds) + "=" +
                Long.toString(this.WiFiInactiveB) + "=" +
                Long.toString(this.CellularActiveSeconds) + "=" +
                Long.toString(this.CellularActiveB) + "=" +
                Long.toString(this.CellularInactiveSeconds) + "=" +
                Long.toString(this.CellularInactiveB) + "=" +
                Long.toString(this.initialB) + "=" +
                Long.toString(this.startOfExecutionTime) + "=" +
                Boolean.toString(this.isRunning) + "=" +
                Boolean.toString(this.isActive) + "=" +
                Boolean.toString(this.dayRunning) + "=" +
                Boolean.toString(this.monthRunning);
        return out;
    }
    //Populate this app object with all parameters from the backup data
    public void setFromString(String input){
        try {
            String[] appData = input.split("=");
            this.setPackageName(appData[0]);
            this.setName(appData[1]);
            this.setUuid(Integer.parseInt(appData[2]));
            this.setMonthRunning(Boolean.parseBoolean(appData[3]));
            this.setDayRunning(Boolean.parseBoolean(appData[4]));
            this.setWiFiActiveSeconds(Long.parseLong(appData[5]));
            this.setWiFiActiveB(Long.parseLong(appData[6]));
            this.setWiFiInactiveSeconds(Long.parseLong(appData[7]));
            this.setWiFiInactiveB(Long.parseLong(appData[8]));
            this.setCellularActiveSeconds(Long.parseLong(appData[9]));
            this.setCellularActiveB(Long.parseLong(appData[10]));
            this.setCellularInactiveSeconds(Long.parseLong(appData[11]));
            this.setCellularInactiveB(Long.parseLong(appData[12]));
            this.setInitialB(Long.parseLong(appData[13]));
            this.setStartOfExecutionTime(Long.parseLong(appData[14]));
            this.setIsRunning(Boolean.parseBoolean(appData[15]));
            this.setIsActive(Boolean.parseBoolean(appData[16]));
            this.setDayRunning(Boolean.parseBoolean(appData[17]));
            this.setMonthRunning(Boolean.parseBoolean(appData[18]));
        }catch(NumberFormatException e){
            e.printStackTrace();
        }
    }
    //===========================================================================================
    //Standard getters and setters used in he code

    public int getUuid() {
        return uuid;
    }

    public void setUuid(int uuid) {
        this.uuid = uuid;
    }

    public void setStartOfExecutionTime(long time){
        startOfExecutionTime = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getWiFiActiveSeconds() {
        return WiFiActiveSeconds;
    }

    public void setWiFiActiveSeconds(long wiFiActiveSeconds) {
        WiFiActiveSeconds = wiFiActiveSeconds;
    }

    public long getWiFiActiveB() {
        return WiFiActiveB;
    }

    public void setWiFiActiveB(long wiFiActiveB) {
        WiFiActiveB = wiFiActiveB;
    }

    public long getWiFiInactiveSeconds() {
        return WiFiInactiveSeconds;
    }

    public void setWiFiInactiveSeconds(long wiFiInactiveSeconds) {
        WiFiInactiveSeconds = wiFiInactiveSeconds;
    }

    public long getWiFiInactiveB() {
        return WiFiInactiveB;
    }

    public void setWiFiInactiveB(long wiFiInactiveB) {
        WiFiInactiveB = wiFiInactiveB;
    }

    public long getCellularActiveSeconds() {
        return CellularActiveSeconds;
    }

    public void setCellularActiveSeconds(long cellularActiveSeconds) {
        CellularActiveSeconds = cellularActiveSeconds;
    }

    public long getCellularActiveB() {
        return CellularActiveB;
    }

    public void setCellularActiveB(long cellularActiveB) {
        CellularActiveB = cellularActiveB;
    }

    public long getCellularInactiveSeconds() {
        return CellularInactiveSeconds;
    }

    public void setCellularInactiveSeconds(long cellularInactiveSeconds) {
        CellularInactiveSeconds = cellularInactiveSeconds;
    }



    public long getCellularInactiveB() {
        return CellularInactiveB;
    }

    public void setCellularInactiveB(long cellularInactiveB) {
        CellularInactiveB = cellularInactiveB;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public void setIsRunning(boolean isRunning) {
        this.isRunning = isRunning;
    }

    public void setStartOfActiveTime(long startOfActiveTime) {
        this.startOfActiveTime = startOfActiveTime;
        this.startOfActiveB = this.getTotalTraffic();
    }

    public void setStopOfActiveTime(long stopOfActiveTime) {
        this.stopOfActiveTime = stopOfActiveTime;
        this.stopOfActiveB = this.getTotalTraffic();
    }

    public boolean isActive() {
        return isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public void setMonthRunning(boolean monthRunning) {
        this.monthRunning = monthRunning;
    }

    public void setDayRunning(boolean dayRunning) {
        this.dayRunning = dayRunning;
    }

    public void setInitialB(long initialB) {
        this.initialB = initialB;
    }

    //=========================================================================================
    //Getters and setters that are not used
    public boolean isMonthRunning() {
        return monthRunning;
    }
    public boolean isDayRunning() {
        return dayRunning;
    }

    public String getPackageName() {
        return packageName;
    }
    public void addWiFiInactiveSeconds(long value){
        this.WiFiInactiveSeconds += value;
    }
    public void addWiFiInactiveB(long value){
        this.WiFiInactiveB += value;
    }
    public void addCellularActiveHours(long value){
        this.CellularActiveSeconds += value;
    }
    public void addCellularActiveB(long value){
        this.CellularActiveB += value;
    }
    public void addCellularInactiveHours(long value){
        this.CellularInactiveSeconds += value;
    }
    public void addCellularInactiveB(long value){
        this.CellularInactiveB += value;
    }
    public void addWiFiActiveSeconds(long value){
        this.WiFiActiveSeconds += value;
    }
    public void addWiFiActiveB(long value){
        this.WiFiActiveB += value;
    }

}
