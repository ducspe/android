package com.example.dan.DataTrafficViewer;

/**
 * Created by Dan on 17.12.2015.
 */
public interface ServerTransferFailedInterruptListener {

    public void managePendingServerTransfers(boolean uploadStatus);
}
