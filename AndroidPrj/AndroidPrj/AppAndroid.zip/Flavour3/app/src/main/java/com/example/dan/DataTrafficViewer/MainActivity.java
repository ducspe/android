package com.example.dan.DataTrafficViewer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.flavour1.WebPageChooserActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private BootComplete mBootCompleteReceiver = null;

    private Button listAllAppsBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button monthSelectBtn;
        int[] btns = {R.id.JanuaryBtn_01, R.id.FebruaryBtn_02, R.id.MarchBtn_03, R.id.AprilBtn_04, R.id.MayBtn_05, R.id.JuneBtn_06, R.id.JulyBtn_07, R.id.AugustBtn_08, R.id.SeptemberBtn_09, R.id.OctoberBtn_10, R.id.NovemberBtn_11, R.id.DecemberBtn_12};
        for (int btn: btns) {
            monthSelectBtn = (Button)findViewById(btn);
            monthSelectBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, AllAppsActivity.class);
                    intent.putExtra("id", v.getResources().getResourceName(v.getId()).split("_")[1]);
                    startActivity(intent);
                }
            });
        }

        listAllAppsBtn = (Button)findViewById(R.id.listAllAppsBtn);

        listAllAppsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AllAppsActivity.class);
                intent.putExtra("id", new DateHandler().getCurrentDayMonth());
                startActivity(intent);
            }
        });
        Log.i("Log", "STARTING SERVICE");
        //Register the BootComplete Broadcast receiver. This makes sure that when the service is stopped,
        //the OS calls it, and that in turn starts up again MyService
	    mBootCompleteReceiver = new BootComplete();
        registerReceiver(mBootCompleteReceiver, new IntentFilter());
        if(!Controller.SERVICE_STARTED){
            startService(new Intent(this, MyService.class));
        }
        Log.i("Log", "SERVICE STARTED");
        

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mBootCompleteReceiver);
        Log.i("Log", "Service destroyed");
    }

    public void setDate(View view){
        PickerDialogs pickerDialogs = new PickerDialogs();
        pickerDialogs.show(getSupportFragmentManager(), "date_picker");
    }

    public boolean onCreateOptionsMenu(Menu menu){

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int itemId = item.getItemId();

        if(itemId == R.id.id_web_page){
            Intent i = new Intent(MainActivity.this, WebPageChooserActivity.class);
            startActivity(i);
        }

        if(itemId == R.id.id_update_frequency){
            Intent i = new Intent(MainActivity.this, UpdateFrequencyActivity.class);
            startActivity(i);
        }
        return true;
    }

    public static class BootComplete extends BroadcastReceiver {
        @Override
        //When the Broadcast receiver get the asynchronous signal the loading of the App is completed
        //This onReceive method is invoked, which in its part starts up the MyService class for our app
        //This can occur only whe the service crashed, the phone restarted ... ,
        //This way it makes the app work allways in the background
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase(Intent.ACTION_BOOT_COMPLETED)) {
                Log.i("Log", "service restart Action Boot Completed");
                Intent serviceIntent = new Intent(context, MyService.class);
                //start service
                context.startService(serviceIntent);
            }
        }
        // default constructor
        public static void BootComplete(){

        }

    }


}
