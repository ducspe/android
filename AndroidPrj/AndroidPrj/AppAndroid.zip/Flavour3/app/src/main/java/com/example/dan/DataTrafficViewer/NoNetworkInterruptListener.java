package com.example.dan.DataTrafficViewer;

/**
 * Created by Dan on 09.12.2015.
 */
public interface NoNetworkInterruptListener {

    public void manageNoNetworkDetection();

}
