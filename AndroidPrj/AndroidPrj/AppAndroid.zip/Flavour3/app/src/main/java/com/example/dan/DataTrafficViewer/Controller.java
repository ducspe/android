package com.example.dan.DataTrafficViewer;
import android.content.Context;
import android.util.Log;
import java.util.ArrayList;
import java.util.Map;

/**
 * Created by Dan on 08.12.2015.
 */

public class Controller {
    protected static boolean SERVICE_STARTED = false;
    protected static int SCREEN_ON = 0;
    protected InterruptManager interruptManager;

    private static MapHandler mapHandler;
    private static DataHandler dataHandler;
    private String previousAppId;
    private int networkStatus;
    private long startOfWifiTime;
    private long startOfCellularTime;
    private String dayFileName;
    private String monthFileName;
    private ArrayList<String> runningApps;
    //private ArrayList<String> pendingDataToSend;
    private boolean uploadStatus;
    protected boolean mySemaphoreLoopFlag;
    public static String FREQUENCY_STRING = "Server will be updated once every 15 minutes";
    public Controller(MapHandler mHandler, Context context) {


        this.runningApps = new ArrayList<String>();
        this.mapHandler = new MapHandler();
        this.dataHandler = new DataHandler(context);
        /*
        boolean flag = clearFile(context, "1901");
        if(flag) Log.i("Log", "DAY Delete successfull");
        else Log.i("Log", "DAY Delete FAIL");

        flag = clearFile(context, "mapBackUp");
        if(flag) Log.i("Log", "MAPBACKUP Delete successfull");
        else Log.i("Log", "MAPBACKUP Delete FAIL");
        /*
        flag = clearFile(context, "01");
        if(flag) Log.i("Log", "MONTH Delete successfull");
        else Log.i("Log", "MONTH Delete FAIL");
        */
        String backUpStr = this.dataHandler.readFromFile("mapBackUp");
        Log.i("Log", "readBackUP" + backUpStr);
        if (backUpStr != "") {
            String[] parts = backUpStr.split("###");
            this.uploadStatus = Boolean.parseBoolean(parts[1]);
            this.mapHandler = new MapHandler(parts[0]);
            this.mapHandler.mergeMap(mHandler.getMap(), false);
        } else {
            this.uploadStatus = false;
            this.mapHandler.setMap(mHandler.getMap());
        }

        interruptManager = new InterruptManager();
        interruptManager.setAppDetectedInterruptListener(new AppDetectedInterruptListener() {
            @Override
            public void manageAppDetection(String appName, String appPackageName, int id) {
                Log.i("Log", "An app was detected with name: " + appName);

                App previousApp = mapHandler.get(previousAppId);

                if (id != 0) {
                    App newApp;
                    if (mapHandler.containsKey(appPackageName)) {
                        newApp = mapHandler.get(appPackageName);
                        newApp.updateInActiveTime(System.currentTimeMillis(), networkStatus);
                        newApp.setStartOfActiveTime(System.currentTimeMillis());
                    } else {
                        Log.i("Log", "reset startofexecutiontime " + appName);
                        newApp = new App(id, appName, appPackageName);
                        newApp.setStartOfExecutionTime(System.currentTimeMillis());
                        newApp.setStartOfActiveTime(System.currentTimeMillis());
                        mapHandler.put(appPackageName, newApp);
                    }
                    Log.i("Log", "App already in list: " + mapHandler.get(appPackageName).toStringForServer());
                    newApp.setIsActive(true);
                }

                if (previousApp != null) {
                    previousApp.updateActiveTime(System.currentTimeMillis(), networkStatus);
                    previousApp.setStopOfActiveTime(System.currentTimeMillis());
                    previousApp.setIsActive(false);
                }

                previousAppId = appPackageName;
            }
        });


        interruptManager.setWifiEnabledInterruptListener(new WifiEnabledInterruptListener() {
            public void manageWifiDetection(String appName) {
                Log.i("Log", "wifi enabled");
                startOfWifiTime = System.currentTimeMillis();
                updateAppTimes(2);
                networkStatus = 2;

            }
        });

        interruptManager.setMobileDataEnabledInterruptListener(new MobileEnabledInterruptListener() {
            public void manageMobileDataDetection() {
                Log.i("Log", "mobile data enabled");
                startOfCellularTime = System.currentTimeMillis();
                updateAppTimes(1);
                networkStatus = 1;
            }
        });


        interruptManager.setNoNetworkInterruptInterruptListener(new NoNetworkInterruptListener() {
            public void manageNoNetworkDetection() {
                Log.i("Log", "not connected to network");
                updateAppTimes(0);
                networkStatus = 0;
            }
        });

        interruptManager.setServerTransferFailedInterruptListener(new ServerTransferFailedInterruptListener() {
            @Override
            public void managePendingServerTransfers(boolean uStatus) {
                //pendingDataToSend.add(failedToSendStr);
                uploadStatus = uStatus;
                resetMap();
            }
        });
    }

    public boolean clearFile(Context context, String file_name) {
        if (context.deleteFile(file_name)) return true;
        return false;
    }

    public void updateAppTimes(int newNetworkStatus) {
        mySemaphoreLoopFlag = true;
        if (networkStatus == 2) {
            for (String packageName : this.runningApps) {
                App app = mapHandler.get(packageName);
                //app.updateWifiTime(System.currentTimeMillis(), startOfWifiTime);
                if (app == null) continue;
                if (app.isActive()) {
                    app.updateActiveTime(System.currentTimeMillis(), networkStatus);
                    app.setStartOfActiveTime(System.currentTimeMillis());
                } else {
                    app.updateInActiveTime(System.currentTimeMillis(), networkStatus);
                    app.setStopOfActiveTime(System.currentTimeMillis());
                }
            }
        } else if (networkStatus == 1) {
            for (String packageName : this.runningApps) {
                App app = mapHandler.get(packageName);
                if (app == null) continue;
                //app.updateCellularTime(System.currentTimeMillis(), startOfCellularTime);
                if (app.isActive()) {
                    app.updateActiveTime(System.currentTimeMillis(), networkStatus);
                    app.setStartOfActiveTime(System.currentTimeMillis());
                } else {
                    app.updateInActiveTime(System.currentTimeMillis(), networkStatus);
                    app.setStopOfActiveTime(System.currentTimeMillis());
                }
            }
        } else {
            //@TODO has to adapt setActiveTime etc
            if (newNetworkStatus == 2) {
                startOfWifiTime = System.currentTimeMillis();
            } else if (newNetworkStatus == 1) {
                startOfCellularTime = System.currentTimeMillis();
            }
        }
        mySemaphoreLoopFlag = false;
    }

    public void setRunningApps(ArrayList<String> packageNames) {
        this.runningApps.clear();
        this.runningApps.addAll(packageNames);
    }

    public void setRunningTime(ArrayList<String> packageNames) {
        if (!mySemaphoreLoopFlag) {
            for (String appPackageName : runningApps) {
                App app = mapHandler.get(appPackageName);
                if (app == null) continue;
                String key = appPackageName;
                if (packageNames.contains(key)) {
                    if (!app.isRunning()) {
                        app.setIsRunning(true);
                        Log.i("Log", "Started running " + app.getName());
                        app.setStartOfExecutionTime(System.currentTimeMillis());
                    }
                } else {
                    if (app.isRunning()) {
                        Log.i("Log", "STOPPED running " + app.getName());
                        app.setIsRunning(false);
                        if (app.isActive())
                            app.updateActiveTime(System.currentTimeMillis(), networkStatus);
                        else app.updateInActiveTime(System.currentTimeMillis(), networkStatus);
                        app.setIsActive(false);
                        app.setStopOfActiveTime(0);
                        app.setStartOfActiveTime(0);
                    }
                }
            }
            this.setRunningApps(packageNames);
        }
    }

    protected void backupData() {
        Boolean uploadStatus = this.uploadStatus;
        String mapStr = this.mapHandler.toString();
        Log.i("Log", "---------------------------------");
        Log.i("Log", this.mapHandler.toStringForServer());
        MapHandler temp = new MapHandler(mapStr);
        Log.i("Log", "WRITTEN TO FILE: "+temp.toStringForServer());
        Log.i("Log", "---------------------------------");
        this.dataHandler.writeToFile("mapBackUp", mapStr + "###" + Boolean.toString(this.uploadStatus));
    }

    protected void resetMap() {
        String mapStr = this.mapHandler.toString();
        MapHandler mHandler = new MapHandler(mapStr);
        Log.i("Log", mapStr + "###" + Boolean.toString(this.uploadStatus));
        Log.i("Log", "From file: ");
        String mapStrFromFile = this.dataHandler.readFromFile(this.dayFileName);
        Log.i("Log", mapStrFromFile);
        Log.i("Log", this.dayFileName);
        Log.i("Log", this.monthFileName);
        Log.i("Log", "---------------------------------");
        if (mapStrFromFile != "") {
            MapHandler mHandlerFromFile = new MapHandler(mapStrFromFile);
            mHandler.mergeMap(mHandlerFromFile.getMap(), true);
        }
        this.dataHandler.writeToFile(this.dayFileName, mHandler.toString());

        mapStrFromFile = this.dataHandler.readFromFile(this.monthFileName);
        Log.i("Log", "---------MONTH----------");
        Log.i("Log", mapStrFromFile);
        Log.i("Log", "---------------------------------");
        if (mapStrFromFile != "") {
            MapHandler mHandlerFromFile = new MapHandler(mapStrFromFile);
            mHandler.mergeMap(mHandlerFromFile.getMap(), true);
        }
        this.dataHandler.writeToFile(this.monthFileName, mHandler.toString());
        this.mapHandler.resetMap();
    }

    protected static MapHandler getMapHandler() {
        return mapHandler;
    }

    protected static MapHandler createMapHandlerFromFile(String filename) {
        String mapStr = dataHandler.readFromFile(filename);
        MapHandler mapHandler;
        if (mapStr != "") {
            mapHandler = new MapHandler(mapStr);
        } else {
            mapHandler = new MapHandler();
        }
        return mapHandler;
    }

    protected void uploadToServer(MyService.ConnectTask connectTask) {
        connectTask.execute(this.mapHandler.toStringForServer());
    }

    protected boolean getUploadStatus() {
        return this.uploadStatus;
    }

    protected void setUploadStatus(boolean s) {
        this.uploadStatus = s;
    }

    protected void setDayFileName(String name) {
        this.dayFileName = name;
    }

    protected void setMonthFileName(String name) {
        this.monthFileName = name;
    }

}
