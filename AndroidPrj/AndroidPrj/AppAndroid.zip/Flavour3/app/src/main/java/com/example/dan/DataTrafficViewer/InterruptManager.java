package com.example.dan.DataTrafficViewer;


/**
 * Created by Dan on 08.12.2015.
 */
public class InterruptManager {

    protected AppDetectedInterruptListener appDetectedinterruptListener;
    protected WifiEnabledInterruptListener wifiEnabledInterruptListener;
    protected MobileEnabledInterruptListener mobileEnabledInterruptListener;
    protected NoNetworkInterruptListener noNetworkInterruptListener;
    protected ServerTransferFailedInterruptListener serverTransferFailedInterruptListener;

    public InterruptManager(){
        
    }

    public void setAppDetectedInterruptListener(AppDetectedInterruptListener appDetectedinterruptListener){
        this.appDetectedinterruptListener = appDetectedinterruptListener;
    }

    public void setWifiEnabledInterruptListener(WifiEnabledInterruptListener wifiEnabledInterruptListener){
        this.wifiEnabledInterruptListener = wifiEnabledInterruptListener;
    }

    public void setMobileDataEnabledInterruptListener(MobileEnabledInterruptListener mobileEnabledInterruptListener){
        this.mobileEnabledInterruptListener = mobileEnabledInterruptListener;
    }

    public void setNoNetworkInterruptInterruptListener(NoNetworkInterruptListener noNetworkInterruptListener){
        this.noNetworkInterruptListener = noNetworkInterruptListener;
    }

    public void setServerTransferFailedInterruptListener(ServerTransferFailedInterruptListener serverTransferFailedInterruptListener){
        this.serverTransferFailedInterruptListener = serverTransferFailedInterruptListener;
    }

}
