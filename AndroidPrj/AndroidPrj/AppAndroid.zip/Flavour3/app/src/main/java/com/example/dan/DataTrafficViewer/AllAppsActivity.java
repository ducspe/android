package com.example.dan.DataTrafficViewer;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

/**
 * Created by Cristi on 18.12.2015.
 This class is responsible to get the intent from the mapHandler regarding the attributes to be displayed in the final GUI 
 */
public class AllAppsActivity extends ListActivity{

    private PackageManager packageManager = null;
    private List<ApplicationInfo> appList = null;
    private ApplicationAdapter listadaptor = null;
    private Timer mTimer;
    private String selection;


    private Context adapterContext;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_apps);

        packageManager = getPackageManager();
        new LoadApplications().execute();
        this.selection = getIntent().getStringExtra("id");

    }

    @Override
    protected void onDestroy() {
        //if(mTimer != null) mTimer.cancel();
        super.onDestroy();
    }

    /*

 */

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        MapHandler mapHandler = Controller.createMapHandlerFromFile(this.selection);
        mapHandler.mergeMap(Controller.getMapHandler().getMap(), true);
        try {
            View view = v;
            ApplicationInfo data = AllAppsActivity.this.listadaptor.getItem(position);
			//read the values for the attributes for the detailed view of every application
			//divide by 1024 to get it in MB
            float wifiActiveB = ((mapHandler.get(data.packageName).getWiFiActiveB())/1024f)/1024f;
            float wifiInactiveB = ((mapHandler.get(data.packageName).getWiFiInactiveB())/1024f)/1024f;
            float cellularActiveB = ((mapHandler.get(data.packageName).getCellularActiveB())/1024f)/1024f;
            float cellularInactiveB = ((mapHandler.get(data.packageName).getCellularInactiveB())/1024f)/1024f;
			//divide by 3600 to get the time in hours (initially it was done in minutes, but due to long time running applications it was changed to hours)
            float wifiActiveTime = (mapHandler.get(data.packageName).getWiFiActiveSeconds())/3600f;
            float wifiInactiveTime = (mapHandler.get(data.packageName).getWiFiInactiveSeconds())/3600f;
            float cellularActiveTime = (mapHandler.get(data.packageName).getCellularActiveSeconds())/3600f;
            float cellularInactiveTime = (mapHandler.get(data.packageName).getCellularInactiveSeconds())/3600f;


			//get the name of the application
            String AppName = mapHandler.get(data.packageName).getName();

            Intent intent = new Intent(AllAppsActivity.this, ParticularAppShow.class);
			//use the method "putExtra" to put the values of intent in order to call them in the class "ParticularAppShow" and there to send them to xml and displaying them in GUI
            intent.putExtra("wifiActiveB", String.valueOf(String.format("%.2f", wifiActiveB)));
            intent.putExtra("wifiInactiveB", String.valueOf(String.format("%.2f",wifiInactiveB)));
            intent.putExtra("cellularActiveB", String.valueOf(String.format("%.2f",cellularActiveB)));
            intent.putExtra("cellularInactiveB", String.valueOf(String.format("%.2f",cellularInactiveB)));

            intent.putExtra("wifiActiveTime", String.valueOf(String.format("%.2f", wifiActiveTime)));
            intent.putExtra("wifiInactiveTime", String.valueOf(String.format("%.2f",wifiInactiveTime)));
            intent.putExtra("cellularActiveTime", String.valueOf(String.format("%.2f",cellularActiveTime)));
            intent.putExtra("cellularInactiveTime", String.valueOf(String.format("%.2f",cellularInactiveTime)));

            intent.putExtra("AppName", AppName);

            startActivity(intent);

        } catch (ActivityNotFoundException e) {

        } catch (Exception e) {

        }
    }
	//check the list applicationInfo
    private List<ApplicationInfo> checkForLaunchIntent(List<ApplicationInfo> list) {
        ArrayList<ApplicationInfo> applist = new ArrayList<ApplicationInfo>();
        for (ApplicationInfo info : list) {
            try {
                if (null != packageManager.getLaunchIntentForPackage(info.packageName)) {
                    applist.add(info);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return applist;
    }

	//method to load the installed applications which will be futher displayed in the GUI
    private class LoadApplications extends AsyncTask<Void, Void, Void> {
        private ProgressDialog progress = null;

        @Override
        protected Void doInBackground(Void... params) {
            appList = checkForLaunchIntent(packageManager.getInstalledApplications(PackageManager.GET_META_DATA));
            listadaptor = new ApplicationAdapter(AllAppsActivity.this, R.layout.list_row, appList, selection);

            return null;
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }


        @Override
        protected void onPostExecute(Void result) {
            setListAdapter(listadaptor);

            adapterContext = listadaptor.sendBackContext();
            progress.dismiss();
            super.onPostExecute(result);
        }

        @Override
        protected void onPreExecute() {
            progress = ProgressDialog.show(AllAppsActivity.this, null,
                    "Loading application info...");
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }

}
