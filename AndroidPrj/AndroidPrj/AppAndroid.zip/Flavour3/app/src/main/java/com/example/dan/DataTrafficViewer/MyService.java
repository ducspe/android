package com.example.dan.DataTrafficViewer;

import android.app.ActivityManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.support.annotation.Nullable;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Dan on 08.12.2015.
 */
public class MyService extends Service {

    //constants for the timers are set
    public static final long FOREGROUND_INTERVAL = 5 * 100; // 0.5 seconds
    public static final long UPLOAD_INTERVAL = 60 * 1 * 1000; // 15 minutes

    //ATTRIBUTE DECLERATIONS
    private Controller controller;
    private int lastSavedMonth;
    private int lastSavedDay;

    private Timer mForegroundTimer = null;
    private Timer mTimer = null;
    private ScheduleUploadsTimerTask mUploadTimer = null;

    private String currentRunningAppName = null;
    private ForegroundBroadcastReceiver mScreenStateReceiver = null;
    private NetworkBroadcastReceiver mNetworkBroadcastReceiver = null;

    private final IBinder iBinder = new LocalBinder();

    public class LocalBinder extends Binder {
        MyService getService(){
            return MyService.this;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return iBinder;
    }

    //function that gets a list of installed apps and adds them to the given mapHandler object
    public void populateInstalledAppMap(MapHandler mapHandler) {
        PackageManager pm = MyService.this.getPackageManager();
        //iterate through the installed apps
        for (ApplicationInfo app: this.getBaseContext().getPackageManager().getInstalledApplications(0)) {
            String appName;
            PackageInfo packageinfo = null;
            //try to get the packagename, if can't skip
            try {
                packageinfo = pm.getPackageInfo(app.packageName, 0);
            } catch (PackageManager.NameNotFoundException e) {
                continue;
            }
            //instantiate an App object, add it to the mapHandler
            appName = packageinfo.applicationInfo.loadLabel(pm).toString();
            mapHandler.put(app.packageName, new App(app.uid, appName, app.packageName));
        }
    }

    //'CONSTRUCTOR'
    @Override
    public void onCreate() {
        super.onCreate();
        Controller.SERVICE_STARTED = true;
        Log.i("Log", "CONSTRUCTOR CALL");
        //installed apps are retrieved and put into the mapHandler object
        MapHandler mapHandler = new MapHandler();
        this.populateInstalledAppMap(mapHandler);
        controller = new Controller(mapHandler, this);
        //foreground and network detecting Broadcastreceivers
        mScreenStateReceiver = new ForegroundBroadcastReceiver();
        mNetworkBroadcastReceiver = new NetworkBroadcastReceiver();

        IntentFilter screenStateFilter = new IntentFilter();
        screenStateFilter.addAction(Intent.ACTION_SCREEN_ON);
        screenStateFilter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mScreenStateReceiver, screenStateFilter);

        //adding actions to detect connection changes
        final IntentFilter networkFilters = new IntentFilter();
        networkFilters.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        networkFilters.addAction("android.net.conn.CONNECTIVITY_CHANGE");

        registerReceiver(mNetworkBroadcastReceiver, networkFilters);
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);

        //if screen is on when the app is started
        //check foreground apps
        //checking the screen is API version dependent therefore version check is required
        mForegroundTimer = new Timer();
        //new api
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.KITKAT_WATCH) {
            if (powerManager.isInteractive()) mForegroundTimer.scheduleAtFixedRate(new CheckForegroundAppsTimerTask(), 0, FOREGROUND_INTERVAL);
        } else { //old api
            if (powerManager.isScreenOn()) mForegroundTimer.scheduleAtFixedRate(new CheckForegroundAppsTimerTask(), 0, FOREGROUND_INTERVAL);
        }
        mNetworkBroadcastReceiver.onReceive(this.getBaseContext(), new Intent());
        //upload scheduler is set and started
        int uploadTime = 1;
        mTimer = new Timer();
        mUploadTimer = new ScheduleUploadsTimerTask(uploadTime);
        mTimer.scheduleAtFixedRate(mUploadTimer, UPLOAD_INTERVAL, UPLOAD_INTERVAL);
    }

    //on destroy method to make sure things are backed up if the app quits
    @Override
    public void onDestroy() {
        unregisterReceiver(mScreenStateReceiver);
        unregisterReceiver(mNetworkBroadcastReceiver);
        if(mForegroundTimer!=null) mForegroundTimer.cancel();
        //if(mTransferTimer!=null) mTransferTimer.cancel();
        this.controller.backupData();
        Log.d("Log", "Service destroyed");

        super.onDestroy();
    }

    //broadcast receiver that detects screen status
    //calls the corresponding interrupt functions
    public class ForegroundBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            //screen is off
            if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                Log.i("Log", "Screen went OFF");
                Controller.SCREEN_ON = 0;
                controller.interruptManager.appDetectedinterruptListener.manageAppDetection("", "", 0);
                //if screen goes off and the timer is active, deactivates the timer
                //stops the foreground app polling
                if(mForegroundTimer != null){
                    mForegroundTimer.cancel();
                }

            } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                //screen is on
                Log.i("Log","Screen went ON");
                Controller.SCREEN_ON = 1;
                //if screen is on, starts the foreground app polling
                mForegroundTimer = new Timer();
                mForegroundTimer.scheduleAtFixedRate(new CheckForegroundAppsTimerTask(), 0, FOREGROUND_INTERVAL);
            }
        }
    }

    //broadcast receiver for detecting the network status
    public class NetworkBroadcastReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            String status = NetworkUtil.getConnectivityStatusString(context);
            //calling the corresponding interrupts in case of wifi mobile and no network
            if(status.equals("Wifi enabled")){
                if( (controller.interruptManager.wifiEnabledInterruptListener != null)){
                    controller.interruptManager.wifiEnabledInterruptListener.manageWifiDetection(currentRunningAppName);
                }
            }
            if(status.equals("Mobile data enabled")){
                if( (controller.interruptManager.mobileEnabledInterruptListener != null)){
                    controller.interruptManager.mobileEnabledInterruptListener.manageMobileDataDetection();
                }
            }
            if(status.equals("Not connected to Internet")){
                if( (controller.interruptManager.noNetworkInterruptListener != null)){
                    controller.interruptManager.noNetworkInterruptListener.manageNoNetworkDetection();
                }
            }
        }
    }

    //getter for the timer
    public ScheduleUploadsTimerTask getmUploadTimer() {
        return this.mUploadTimer;
    }

    //timer that schedules uploads and backing up process
    class ScheduleUploadsTimerTask extends TimerTask {
        //defines the upload schedule by 15 minute intervals, like every 15, 30, 45, 60, 75 etc
        //if 15 given uploads every 15 minutes, 30 for every 30min and so on
        private int uploadTime;
        private DateHandler dateHandler;
        private boolean newDay;
        private boolean newMonth;

        //constructor
        public ScheduleUploadsTimerTask(int uploadTime) {
            super();
            this.uploadTime = uploadTime;
            this.dateHandler = new DateHandler();
            this.dateHandler.setPreviousTimeStamp();
            this.newDay = false;
            this.newMonth = false;
            //stores the last saved month and last saved day to be able to detect
            //changes in day and month so it can act accordingly
            lastSavedMonth = this.dateHandler.getCurrentMonthInt();
            lastSavedDay = this.dateHandler.getCurrentDayInt();
            controller.setDayFileName(this.dateHandler.getCurrentDayMonth());
            controller.setMonthFileName(this.dateHandler.getCurrentMonth());
        }

        //setter to define a new upload frequency
        public void setUploadTime(int newUploadTime) {
            this.uploadTime = newUploadTime;
        }

        //check upload boolean indicating success of the upload process
        //if boolean is true then update dateHandler previousTimeStamp to now, simply call the setter
        //else leave it so it would try to upload in 15minutes again
        //corresponding booleans for day and months are set to true begining of a day and begining of a month
        //so that number of users can be calculated correctly on the server side
        //once the data is sent to the server, day flag and month flag are set to false, signalling that
        //this user has sent data for that app during today or this month, telling the server not the increase #users
        @Override
        public void run() {
            //detect a new day
            if (this.dateHandler.getCurrentDayInt() != lastSavedDay) {
                //if its a new day, get the full list of installed apps and adapt
                MapHandler mapHandler = new MapHandler();
                populateInstalledAppMap(mapHandler);
                controller.getMapHandler().mergeMap(mapHandler.getMap(), false);
                //update the day file name so the data for the day can be saved to the correct day file
                controller.setDayFileName(this.dateHandler.getCurrentDayMonth());
                lastSavedDay = this.dateHandler.getCurrentDayInt();
                this.newDay = true;
                //set the day flags to true for every app that is in the mapHandler
                controller.getMapHandler().setDayFlag(true);
                //check if it's a new month
                if (this.dateHandler.getCurrentMonthInt() != lastSavedMonth) {
                    //update month data file name
                    controller.setMonthFileName(this.dateHandler.getCurrentMonth());
                    lastSavedMonth = this.dateHandler.getCurrentMonthInt();
                    this.newMonth = true;
                    //set the month flags to true for every app that is in the mapHandler
                    controller.getMapHandler().setMonthFlag(true);
                }
            }
            //tell the controller to backup data in case of a crash
            controller.backupData();
            //check if it's time to upload data to server, if the upload status from the previous call is false
            //don't wait, do the upload again
            if (this.dateHandler.hasItBeenMinutes(this.uploadTime) && !controller.getUploadStatus()) {
                controller.uploadToServer(new ConnectTask());
            } else {
                //if it hasn't been enough time since the last upload and if the previous upload was successful
                //revert the upload flag, update the previous upload time stamp
                if (controller.getUploadStatus()) {
                    controller.setUploadStatus(false);
                    this.dateHandler.setPreviousTimeStamp();
                    if (this.newDay) {
                        if (this.newMonth) {
                            this.newMonth = false;
                        }
                        this.newDay = false;
                    }
                }
            }
        }
    }

    //timer to poll the foreground apps when the screen is on
    class CheckForegroundAppsTimerTask extends TimerTask {
        @Override
        public void run() {
            String foregroundAppName = "";
            String foregroundPackageName = "";
            int foregroundUid = 0;
            boolean existsForegroundApp = false;
            ArrayList<String> runningTaskPackageNames = new ArrayList<String>();

            //get the list of running apps and the foreground app
            //same procedure, different function calls for the new api and the old api
            //new api
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                List<AndroidAppProcess> runningApps = ProcessManager.getRunningAppProcesses();
                List<AndroidAppProcess> foregroundApps = ProcessManager.getRunningForegroundApps(getBaseContext());
                if (foregroundApps.size() > 0) {
                    existsForegroundApp = true;
                    foregroundAppName = foregroundApps.get(0).name;
                    foregroundPackageName = foregroundApps.get(0).getPackageName();
                    foregroundUid = foregroundApps.get(0).uid;
                    for (AndroidAppProcess p: runningApps) runningTaskPackageNames.add(p.getPackageName());
                }
            } else { //old api
                ActivityManager am = (ActivityManager) MyService.this.getSystemService(ACTIVITY_SERVICE);
                List<ActivityManager.RunningTaskInfo> runningTasksOldApi = am.getRunningTasks(10000);
                foregroundPackageName = runningTasksOldApi.get(0).topActivity.getPackageName();
                try {
                    PackageManager pm = MyService.this.getPackageManager();
                    foregroundUid = pm.getPackageInfo(foregroundPackageName, 0).applicationInfo.uid;
                    foregroundAppName = pm.getPackageInfo(foregroundPackageName, 0).applicationInfo.loadLabel(pm).toString();
                    existsForegroundApp = true;
                    for (ActivityManager.RunningTaskInfo process: runningTasksOldApi) runningTaskPackageNames.add(process.topActivity.getPackageName());
                } catch (PackageManager.NameNotFoundException e) {
                    //do nothing, existsForegroundApp boolean is already set to false
                }

            }
            //if there is a foreground app
            //pass the list of running apps to the controller
            if (existsForegroundApp) {
                controller.setRunningTime(runningTaskPackageNames);
                //check if it's a new foreground app, if yes issue the interrupt
                if(!foregroundAppName.equals(currentRunningAppName)) {
                    currentRunningAppName = foregroundAppName;
                    if( (controller.interruptManager.appDetectedinterruptListener != null)){
                        controller.interruptManager.appDetectedinterruptListener.manageAppDetection(foregroundAppName, foregroundPackageName, foregroundUid);
                    }
                }
            }
        }
    }


//-----------------------------------------------------------------------------------------------------------------------------------------------------------
    public static final String SERVER_IP = "141.22.15.229";
    public static final int SERVER_PORT = 7358;
    private NetworkController networkController;
    private String serverMessage;
    private PrintWriter outString;

    public class ConnectTask extends AsyncTask<String, String, Void> {
        @Override
        protected Void doInBackground(String... stringToSend) {
            if (stringToSend[0].getBytes().length == 0) return null;
            Socket socket = null;
            InetAddress serverAddr = null;
            try {

                serverAddr = InetAddress.getByName(SERVER_IP); // com
                Log.d("Log", "Client: Connecting...");  // com

                socket = new Socket(serverAddr,SERVER_PORT);
                Log.d("Log", "Connected..." + socket.toString());

                outString = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                serverMessage = null;

                if (outString != null && !outString.checkError()) {
                    outString.println(stringToSend[0]);
                    Log.i("Log", stringToSend[0]);
                    Log.d("Log", String.valueOf(stringToSend[0].getBytes().length));
                    outString.flush();
                }
                //----------------------------------------------------------------------------------------------------------------

                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                serverMessage = in.readLine();
                //controller.interruptManager.serverTransferFailedInterruptListener.managePendingServerTransfers(true);
                //controller.resetMap();

                if(serverMessage == null){
                    Log.i("Log", "Server returned null");
                    controller.interruptManager.serverTransferFailedInterruptListener.managePendingServerTransfers(false);
                };

                if (serverMessage != null) {
                    Log.i("Log", serverMessage);
                    if (!serverMessage.equals(String.valueOf(stringToSend[0].getBytes().length))) {
                        controller.interruptManager.serverTransferFailedInterruptListener.managePendingServerTransfers(false);
                    } else {
                        if (outString != null && !outString.checkError()) {
                            outString.println("OK");
                            outString.flush();
                            Log.d("Log", "SENT OK TO THE SERVER");
                        }
                        controller.interruptManager.serverTransferFailedInterruptListener.managePendingServerTransfers(true);
                    }
                }
                //----------------------------------------------------------------------------------------------------------------

            } catch (Exception e){
                Log.e("Log", "Transfer to server failed");
                if(controller.interruptManager.serverTransferFailedInterruptListener != null){
                    controller.interruptManager.serverTransferFailedInterruptListener.managePendingServerTransfers(false);
                }

                //MyService.this.mTransferTimer.schedule(new ServerTransferTimerTask(), SERVER_TRANSFER_INTERVAL);
                return null;

            }
            finally {
                if(socket == null) {
                    Log.i("Log", "Socket is null");
                   //MyService.this.mTransferTimer.schedule(new ServerTransferTimerTask(), SERVER_TRANSFER_INTERVAL);
                   return null;
                }

                else{
                    try {
                        socket.close();
                        Log.e("Log", "Socket closed: " + socket.toString());
                    } catch (IOException e) {
                        Log.e("Log", "Cannot close socket: " + socket.toString());
                    }
                }

            }

            //MyService.this.mTransferTimer.schedule(new ServerTransferTimerTask(), SERVER_TRANSFER_INTERVAL);
            return null;

        }

        @Override
        protected void onProgressUpdate(String... values) {  //"String..." means that zero or more String objects (or an array of them) may be passed as the parameter(s) for this function.
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    } // end of the asyncTask
}
