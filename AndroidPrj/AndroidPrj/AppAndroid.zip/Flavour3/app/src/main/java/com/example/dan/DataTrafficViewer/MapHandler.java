package com.example.dan.DataTrafficViewer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by sbcemberci on 17/12/15.
 */
// a handler class to work with a given map object
public class MapHandler {

    private Map<String, App> map = new HashMap<String, App>();

    public MapHandler() {
        this.map = new HashMap<String, App>();
    }

    public MapHandler(String mapStr) {
        this.map = new HashMap<String, App>();
        this.setFromString(mapStr);
    }

    public void put(String key, App app) {
        this.map.put(key, app);
    }

    public App get(String key) {
        return this.map.get(key);
    }

    //to string method to backup a map
    //it only backs up the apps that either have some data recorded, or have flags that are set to false
    //meaning apps that have been uploaded to the server
    public String toString() {
        String str = "";
        int i = 0;
        for (Map.Entry<String, App> entry: this.map.entrySet()) {
            if (!entry.getValue().getMeasurements().equals("00000000") || (!entry.getValue().isDayRunning() || !entry.getValue().isMonthRunning())) {
                if (i!=0) str+="\n";
                str += entry.getValue().toString();
                i++;
            }
        }
        return str;
    }

    //a function to reconstruct a map from a given string
    public void setFromString(String input) {
        this.map = new HashMap<String, App>();
        String[] entries = input.split("\n");
        String keyValuePair;
        for (String entry: entries) {
            keyValuePair = entry.split("=")[0];
            //an app is created with all parameters including package name
            //this.put(keyValuePair[0], new App(keyValuePair[1]));
            if(entry != "")
                this.put(keyValuePair, new App(entry));
        }
    }

    //reduced toString method
    //it only extracts the key information required by ther server
    //if there is no data recorded for a given app, it skips
    public String toStringForServer() {
        String str = "";
        int i = 0;
        for (Map.Entry<String, App> entry: this.map.entrySet()) {
            //if (entry.getValue().isDayRunning()) str += entry.getKey()+":"+entry.getValue().toStringForServer()+"\t\t";
            if (!entry.getValue().getMeasurements().equals("00000000")) {
                if (i!=0) str+="###";
                str += entry.getValue().toStringForServer();
                i++;
            }
        }
        return str;
    }

    //a method to merge a given map to this.map
    //boolean advancedMerge defines if only the keys in the map are going to be matched
    //or if an app is going to be fully cloned over
    public void mergeMap(Map<String, App> m, boolean advancedMerge) {
        Set<String> keys = this.map.keySet();
        ArrayList<String> keysArray = new ArrayList<String>();
        for (String key: keys) keysArray.add(key);
        for (Map.Entry<String, App> entry: m.entrySet()) {
            if (!this.map.containsKey(entry.getKey())) {
                this.map.put(entry.getKey(), entry.getValue());
            } else {
                this.map.get(entry.getKey()).setUuid(entry.getValue().getUuid());
                if (advancedMerge) this.map.get(entry.getKey()).addApp(entry.getValue());
            }
        }
        for (String key: keysArray) {
            if (!m.containsKey(key)) {
                this.map.remove(key);
            }
        }
    }

    //a method to reset apps in the map that have a valid measurement
    //called after an upload
    public void resetMap() {
        for (Map.Entry<String, App> entry: this.map.entrySet()) {
            if (!entry.getValue().getMeasurements().equals("00000000")) {
                entry.getValue().setDayRunning(false);
                entry.getValue().setMonthRunning(false);
            }
            entry.getValue().resetApp();
        }
    }

    //sets all the day flags inside the map to true
    public void setDayFlag(Boolean dayFlag) {
        for (Map.Entry<String, App> entry: this.map.entrySet()) {
            entry.getValue().setDayRunning(dayFlag);
        }
    }
    //sets all the month flags inside the map to true
    public void setMonthFlag(Boolean monthFlag) {
        for (Map.Entry<String, App> entry: this.map.entrySet()) {
            entry.getValue().setMonthRunning(monthFlag);
        }
    }

    public boolean containsKey(String key) {
        return this.map.containsKey(key);
    }

    public Map<String, App> getMap() {
        return this.map;
    }

    public void setMap(Map<String, App> map) {
        this.map.putAll(map);
    }
}
