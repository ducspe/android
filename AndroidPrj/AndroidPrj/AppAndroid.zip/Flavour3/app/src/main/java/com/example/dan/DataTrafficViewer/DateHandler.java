package com.example.dan.DataTrafficViewer;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Berk on 17/12/15
 */

public class DateHandler {

    //variable to store a given timestamp for comparisons
    private long previousTimeStamp;

	public String getCurrentDate() {
		String dateStr = this.getDateTimeStr();
        return dateStr.split("-")[0];
	}
	
	public String getCurrentTime() {
		String dateStr = this.getDateTimeStr();
		return dateStr.split("-")[1];
	}

    //different functions to get different data types for day, month, hour, minute, year etc
    public long getCurrentTimeMillisMinutes() {
        return System.currentTimeMillis()/1000/60;
    }

    public String getCurrentHour() {
        return getCurrentTime().split(":")[0];
    }

    public String getCurrentDayMonth() {
        return this.getCurrentDay()+this.getCurrentMonth();
    }

    public int getCurrentHourInt() {
        return Integer.parseInt(this.getCurrentHour());
    }

    public String getCurrentMinute() {
        return getCurrentTime().split(":")[1];
    }

    public int getCurrentMinuteInt() {
        return Integer.parseInt(getCurrentMinute());
    }

    public String getCurrentDay() {
        return getCurrentDate().split("_")[0];
    }

    public String getCurrentMonth() { return getCurrentDate().split("_")[1]; }

    public int getCurrentMonthInt() {
       return Integer.parseInt(this.getCurrentMonth());
    }

    public int getCurrentDayInt() {
        return Integer.parseInt(this.getCurrentDay());
    }

    public String getCurrentYear() {
        return getCurrentDate().split("_")[2];
    }

    public long getPreviousTimeStamp() {
        return this.previousTimeStamp;
    }

    public void setPreviousTimeStamp() {
        this.previousTimeStamp = this.getCurrentTimeMillisMinutes();
    }

    public boolean hasItBeenMinutes(int minutes) {
        return ((this.getCurrentTimeMillisMinutes() - this.previousTimeStamp) > (minutes*1l));
    }

	private String getDateTimeStr() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy-HH:mm");
		Date date = new Date();
		return dateFormat.format(date);
	}
}
