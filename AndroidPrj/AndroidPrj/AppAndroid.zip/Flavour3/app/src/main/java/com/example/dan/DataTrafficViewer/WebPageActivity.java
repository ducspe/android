package com.example.dan.DataTrafficViewer;

import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;


public class WebPageActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_web_page);

        String url=null;

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            url = extras.getString("url_data");
        }

        WebView view = (WebView) this.findViewById(R.id.webView);
        view.getSettings().setJavaScriptEnabled(true);
        view.loadUrl(url);
    };

}
