package com.example.dan.DataTrafficViewer;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.widget.DatePicker;
import android.widget.Toast;

/**
 * Created by Dan on 04.01.2016.
 */

public class DateSettings implements DatePickerDialog.OnDateSetListener{

    Context context;

    public DateSettings(Context context) {
        this.context = context;
    }


    @Override
    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        Intent intent = new Intent(context, AllAppsActivity.class);
        intent.putExtra("id", Integer.toString(dayOfMonth)+Integer.toString(monthOfYear));
        context.startActivity(intent);
    }
}