package com.example.dan.DataTrafficViewer;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class UpdateFrequencyActivity extends AppCompatActivity {
    private TextView final_result;
    private MyService myService;
    private boolean isBound = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_frequency);

        Intent intent = new Intent(this, MyService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);

        final_result = (TextView)findViewById(R.id.result_text);

        final_result.setEnabled(true);
        final_result.setText(Controller.FREQUENCY_STRING);

        RadioGroup rg = (RadioGroup)findViewById(R.id.rg1);
        //int[] rb = {R.id.sixhours, R.id.hourly, R.id.each30minute, R.id.each15minute};

        if(Controller.FREQUENCY_STRING.equals("Server will be updated once in 6 hours")){
            rg.check(R.id.sixhours);
        }

        if(Controller.FREQUENCY_STRING.equals("Server will be updated once an hour")){
            rg.check(R.id.hourly);
        }

        if(Controller.FREQUENCY_STRING.equals("Server will be updated once every 30 minutes")){
            rg.check(R.id.each30minute);
        }

        if(Controller.FREQUENCY_STRING.equals("Server will be updated once every 15 minutes")){
            rg.check(R.id.each15minute);
        }
    }

    @Override
    protected void onDestroy() {
        unbindService(serviceConnection);
        super.onDestroy();
    }

    public void selectUpdateFrequency(View view){
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()){
            case R.id.sixhours:
                if(checked) {
                    final_result.setText("Server will be updated once in 6 hours");
                    Controller.FREQUENCY_STRING = "Server will be updated once in 6 hours";
                    final_result.setEnabled(true);
                    //myService.resetServerTransferTimer(12*3600*1000);
                    myService.getmUploadTimer().setUploadTime(12*60);
                }else{
                    final_result.setEnabled(false);
                }
                break;
            case R.id.hourly:
                if(checked) {
                    final_result.setText("Server will be updated once an hour");
                    Controller.FREQUENCY_STRING = "Server will be updated once an hour";
                    final_result.setEnabled(true);
                    //myService.resetServerTransferTimer(3600*1000);
                    myService.getmUploadTimer().setUploadTime(60);
                }else{
                    final_result.setEnabled(false);
                }
                break;
            case R.id.each30minute:
                if(checked) {
                    final_result.setText("Server will be updated once every 30 minutes");
                    Controller.FREQUENCY_STRING = "Server will be updated once every 30 minutes";
                    final_result.setEnabled(true);
                    //myService.resetServerTransferTimer(10 * 1000);
                    myService.getmUploadTimer().setUploadTime(30);
                }else{
                    final_result.setEnabled(false);
                }
                break;
            case R.id.each15minute:
                if(checked) {
                    final_result.setText("Server will be updated once every 15 minutes");
                    Controller.FREQUENCY_STRING = "Server will be updated once every 15 minutes";
                    final_result.setEnabled(true);
                    //myService.resetServerTransferTimer(10*1000);
                    myService.getmUploadTimer().setUploadTime(15);
                }else{
                    final_result.setEnabled(false);
                }
                break;
        }
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MyService.LocalBinder binder = (MyService.LocalBinder) service;
            myService = binder.getService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };
}
