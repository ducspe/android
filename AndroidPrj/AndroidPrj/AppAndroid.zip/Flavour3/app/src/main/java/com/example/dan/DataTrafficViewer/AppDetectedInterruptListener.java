package com.example.dan.DataTrafficViewer;

/**
 * Created by Dan on 08.12.2015.
 */
public interface AppDetectedInterruptListener {

    public void manageAppDetection(String appName, String appPackageName, int id);

}
