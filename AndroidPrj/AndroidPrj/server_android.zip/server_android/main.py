from sys import exit
from classes.Listener import Listener
from classes.Logger import Logger
import re

if __name__ == "__main__":
	#read the port number from the .config file
	port = 0
	f = open(".config", "r")
        for line in f:
                if re.search("port", line):
                        port = int(line.split("=")[-1])
                        break
        f.close()
	
	#instantiate objects
	listener = Listener()
	logger = Logger()
	
	#try to bind to the port read
	#if it fails, log the error, and exit 		
	flag, message = listener.bind("", port)
	if not flag:
		logger.appendErrorLog(message)
		exit()
	
	#while loop to continuously listen to the port
	#a false flag from the listen() call indicates the exit message is received
	#therefore in that case the loop is broken
	#if a message other than 'exit' is received, listen() method returns true
	#in that case the message is retrieved from the listener object by the get_message() call
	#and put into the log files	
	while True:
		if not listener.listen():
			break
		flag, message = listener.get_message()
		if flag:
			logger.updateLog(message)
