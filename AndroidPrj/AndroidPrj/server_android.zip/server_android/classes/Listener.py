import socket, sys
from time import sleep
from re import sub

class Listener:
	#constructor
	def __init__(self):
		self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.message = ""
		self.received_message_flag = False
				
	def bind(self, host, port):
		#tries to bing to the given host and port
		#if that doesn't fail, calls the listen() method of the socket
		#argument '5' here indicates the maximum allowed simultaneous connections
		#the default max number is 5, therefore 5 is given
		try:
			self.server_socket.bind((host, port))
			self.server_socket.listen(1)
			return True, ""
		except:
			return False, "\n> Error: Couldn't establish connection to {host}:{port}".format(host=host, port=port)

	#getter for the message
	#returns true together with the message itself if the message isn't empty
	def get_message(self):
		if self.message != "" and self.received_message_flag:
			msg = self.message
			self.message = ""
			self.received_message_flag = False
			return True, msg
		else:
			return False, ""

	#sends the acknowlegment back to the client
	#acknowlegment here is the length of the received message
	#-1 is used to make sure terminator isn't counted
	def send_ack(self, conn, message):
		try:
			conn.send(str(len(message)-1)+"\n")
		except:
			pass

	#when it is called, starts listening to the port by the accept() method call
	#once there is an incoming connection, sets the timeout of the socket to half a second
	#and starts reading the incoming message char by char
	#conn.recv(1) fails if there isn't any incoming byte for 0.5 seconds
	#if the message is exit, returns false
	#otherwise saves the message and calls the send_ack method followed by a return true
	def listen(self):
		conn, addr = self.server_socket.accept()
		conn.settimeout(1)
		message = ""
		try:
			while True:
				byte = conn.recv(1)
				if byte=="":	
					break
				else:
					message+=byte
		except:
			pass
		if message=="exit":
			return False
		elif message != "":
			self.send_ack(conn, message)
			conn.settimeout(2);
			dataStatus = ""
			try:
				while True:
					byte = conn.recv(1)
					if byte=="":
						break
					else:
						dataStatus+=byte
			except:		
				pass
			if sub("\\n","",dataStatus)=="OK":
				self.received_message_flag = True
				self.message=message
			print "dataStatus:"+dataStatus+":\t"+message		
		conn.close()
		return True
