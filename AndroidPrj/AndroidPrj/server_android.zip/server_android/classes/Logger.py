import os, datetime
from shutil import move

#The Logger Class handles the information comming from the client, 
#parses it, and stores it to the according files
#If an error occurs during parsing, the appropriate error message is apended to the error log
class Logger:
	#The class holds information like date, path, string splitters and flags
	#so that it will be available from all methods
	def __init__(self):
		self.updateDayMonth()
		self.year = str(datetime.date.today().year)		
		self.path = os.getcwd() + "/logs/"
		self.setPath()
		self.splitAppData = "==="
		self.splitApps = "###"
		self.processAppsDaily = 0
		self.processAppsMonthly = 1
	
	#a function to update day month info so the data can be stored in the right files
	def updateDayMonth(self):
		self.day = str(datetime.datetime.now().date()).split("-")[2]
		self.month = str(datetime.datetime.now().date()).split("-")[1]

	#The setPath() method sets, or creates the path apropriate the the time of invoking
	#Since the client does not sent a timestamp regarding the measurement time, 
	#Theserves uses the local system clock time, and sets the path to the /logs/ folder 
	def setPath(self):		
		if not os.path.isdir(self.path + self.year):
			os.makedirs(self.path + self.year)
		self.path =  self.path + self.year + "/"
	
	#The Method that is called by the main(). It takes directly the string passed by the client
	def updateLog(self, text):
		#Set the current month, and day
		self.updateDayMonth() #gets the current day and month info
		monthPath = self.path+self.month
		#Since all files are in the same folder, the days contain the month to which they belong
		#format mm.dd
		dayPath = self.path+self.month + "." + self.day 		
		
		if (text == ""): return
		print "VALID MSG RECEIVED:LOGGING"
		
		#Split the client string in order to get a separate string for each App
		try:
			clientData = text.split(self.splitApps)
		except:			
			return self.appendErrorLog("Corrupt Data: Missing or wrong app strig splitter.")
			
			
		#The daily and monthly data come within the same information, but they are handeled according 
		#to their flags separately
		successfullMonthHandled = self.handleFiles(clientData, monthPath, self.processAppsMonthly)
		successfullDayHandeled = self.handleFiles(clientData, dayPath, self.processAppsDaily)
		
		if (successfullMonthHandled == True and successfullDayHandeled == True): return self.appendErrorLog("Success")
		else : return
		
		
	#The handleFiles() method processes the input strings eather for daily or monthly data
	#Also here all the file handling is made
	#All the enw data is written to a temp file, and everything is successfull, its path is overwritten
	#with the correct one
	def handleFiles(self,clientData, filePath, processFlag):
		#set path for the temp file. It is also in the /logs/ folder
		tempPath = self.path + "temp"
		if not os.path.isfile(filePath):
			oldFile = open(filePath , "w").close()
		newFile = open(tempPath, "w")#open for writing
		oldFile = open(filePath ,"r")#open for reading
		
		#Process the client data, and write it to the temp file		
		successfull = self.processNewApps(oldFile, newFile, clientData, processFlag)	
		
		#whatever happens, close all files				
		newFile.close()
		oldFile.close()	
		
		#Either overwrite the old file with the new data from the temp file
		#OR remove the temp file, and the new data is discarded
		try:		
			#If successfull overwrite the temp file path so that now it becomes either
			#a day or a month file
			if successfull:				
				move(tempPath, filePath)
				return True
			#If processing had errors, remove the temp file and discard the new information 
			else:
				os.remove(tempPath)
				return False			
		except:				
			return False , self.appendErrorLog("IO error.")
	
	#The ProcessNewApps() method, goes through each app data sent by te client, parses it
	#appends the new data to the old data, and if the case write an error message in he log
	def processNewApps(self, oldFile, newFile, clientData, processFlag):
		#It is important here to make a deep copy of the string, so that this method could be called
		#multiple times
		tempClientData = list(clientData)
		
		#Read the old file line by line. Each line representing the data for a single app
		for oldFileApp in oldFile:
			#flag used to deremine if an app from the server file is not present in the 
			#new client data. By default is set to false
			found = False
			
			#Split the server app string by the preset splitter "==="
			fileAppArray = oldFileApp.split(self.splitAppData)
			
			#Go through each of the client app strings compare them. 
			for newAppData in tempClientData:
				#Convert the client app into an array
				succesfull ,newAppArray, flags = self.createAppArray(newAppData, newFile, oldFile)
				
				#If an error ocurred return False
				if not succesfull: 
					return False
				#Compare the names of the current client app and the server current app
				if newAppArray[2] == fileAppArray[0]:
					#If there is a match, it is necessary to add the new client contents to the server app contents 
					successfull, updatedApp = self.addData( fileAppArray, flags[processFlag], newAppArray)
					
					#If not sucessfull return False, and append the log
					if successfull == False: 
						return False, self.appendErrorLog(updatedApp + newAppData)
					
					#Write the updated contents of the common app to the temp file	
					newFile.write(updatedApp+"\n")
					
					#remove the found app from the client data, since it was allready used
					tempClientData.pop(tempClientData.index(newAppData))
					
					#Mark that there was a match and breack
					found = True
					break
			#If the current server file app was not found in the new client data, meaning it is
			#not necessary to update it, save the data as it was in the server file to the temp file
			if not found and oldFileApp != "":							
				newFile.write(oldFileApp)
		
		#If there are apps in the new client data, and not in the server file, simply append them
		#to the temp file
		if(len(tempClientData) != 0):
			#Go through each client app that was not found on the server
			for newAppData in tempClientData:	
				#Convert the client app into an array			
				succesfull , newAppArray, flags = self.createAppArray(newAppData, newFile, oldFile)
				
				#If not successfull return False
				if not succesfull: 
					return False		
					
				#If successfull it is only necessary to append the app.
				#However it is still necessary to go throughthe whole string and parse it#
				#In order to make sure that the data saved on the server files is not corrupt	
				if flags[processFlag] == False:						
					continue
					
				succesfull, updatedApp = self.appendApp(flags[processFlag], newAppArray)
				
				#If not sucessfull return False, and append the log
				if not succesfull:
					self.appendErrorLog(updatedApp + newAppData)
					return False	
					
				#Add the new Client app to the temp file	
				newFile.write(updatedApp+"\n")
		
		#If no errors occur return True 		
		return True
	
	#The createAppArray converts a app String in an array, in order to be easier to process
	#There is a separate method for this, in order to detect if the app string is formated correctly	
	def createAppArray(self, newAppData, newFile, oldFile):	
		flags = None	
		try:					
			newAppArray = newAppData.split(self.splitAppData)			
			flags = (self.getFlags(newAppArray[0]), self.getFlags(newAppArray[1]))
			#check if name is empty
			if(newAppArray[2] == ""):
				selfAppendErrorLog("Corrupt Data: App name is null")				
				return(False, None, None)				
			return (True, newAppArray, flags)			
		except:
			#In case of failure remove the temp file
			newFile.close()
			oldFile.close()
			os.remove(self.path+"temp")
			
			if(flags == None):	
				self.appendErrorLog("Corupt Data: Missing flags")				
			else:	
				self.appendErrorLog("Corrupt Data: Missing or wrong appData strig splitter.")			
			return (False, None, None)
	
	#def getFlags(self, flags):		
	#	flag1 = self.getBoolean(flags[0])
	#	flag2 = self.getBoolean(flags[1])
	#	return (flag1, flag2)
	
	#MEthod used to determine the value of the daytime, monthly data flags from the client
	def getFlags(self, flag):		
		if flag == "true":
			return True
		else:
			return False		
	
	#The addData() method is used for addinf the data of the new client app, to the old server data
	#of the same app
	def addData(self, fileAppArray, flag, newAppArray):
		output = fileAppArray[0] + self.splitAppData
					
		#If the fag is True, it indicates that the number of users for this app,
		#In this file needs to increment	
		if(flag == True):
			output += str(int(fileAppArray[1]) + 1)	
		#else the nr of users remains the same. Which means that for this data period, 
		#this particular client has allready sent data for this app
		elif(flag == False):			
			output += fileAppArray[1]
			
		#Add all data ellements from teh server app with the new client app
		#It makes sure that Mb are added to Mb, and Hours are added to Hours						
		for index in range(2, len(fileAppArray)):
			#add the data elements, and append it to the utput string
			try:
				output += self.splitAppData + str(long(fileAppArray[index]) + long(newAppArray[index+1]))
			#write appropriate error message with the string that failed
			except:								
				return (False , "Error: Failure while parsing -> ")			
		return (True, output)
	
	#The appendApp() method is used when there is a app in the new client data,
	#that is not present in the server file	
	def appendApp(self, flag, newAppArray):
		#save the name of the new app
		output = newAppArray[2] 
		
		#Since it is a new app, set the nr of users to 1
		if(flag == True):
			output += self.splitAppData + str(int(1))	
			
		#Add all data ellements from teh server app with the new client app
		#It makes sure that Mb are added to Mb, and Hours are added to Hours			
		for index in range (3, len(newAppArray)):
			try:
				output += self.splitAppData + str(long(newAppArray[index]))
			except:
				#write appropriate erroe message with the string that failed
				return False , "Error: Failure while parsing ->"					
		return (True, output)
	
	#This method write the passed error string, writes it the appropriate log file, 
	#and append a timestamp to each error message
	#The log files are kept monthly	
	def appendErrorLog(self, error):
		date = str(datetime.datetime.now().date())
		time = str(datetime.datetime.now().time()).split('.')[0]
		if not os.path.isfile(self.path+".log"+self.month):
			open(self.path+".log"+self.month, "w").close()
		open(self.path+".log"+self.month, "a").write("["+date+":"+time+"]: "+error+"\n")

#logger = Logger()
#logger.updateLog("false===false===Copter===0===0===7485===0===0===0===0===0###false===false===Settings===0===0===7452===546===0===0===0===0###false===true===DataTrafficApp===0===0===7485===0===0===0===0===0")
