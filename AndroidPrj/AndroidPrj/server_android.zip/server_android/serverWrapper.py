import os, re, subprocess
from time import sleep

#runs a given command and returns a pipe object referring to that process
#can create a blocking or non blocking call of the command, if the blocking is set to true, it simply wait
#till the given command is fully executed, if set to false, calls the command so it can be executed in the background
#while the code can continue
#output_file defines if the stdout of the given process is going to be stored in a file
#if no output_file is set, stdout is buffered
def runCommand(cmd, blocking=False, output_file=None):
        if output_file != None:
                pipe = subprocess.Popen(cmd, stdout=output_file, stderr=subprocess.PIPE)
        else:
                pipe = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if blocking:
                pipe.wait()
        return pipe

#gets pids of a given process name
#lists only the processes that belong to the user w15cpteam3
def getPIDs(pName):
        pIds = []
        cmd = "ps -u w15cpteam3"
        pipe = runCommand(cmd.split(), blocking=True)
        out, err = pipe.communicate()
        out = out.split("\n")
        for line in out:
                if not re.search(pName, line): continue
                try:
                        pId = line.strip().split()[0]
                        int(pId)
                        pIds.append(pId)
                except:
                        pass
        return pIds

#if there is only 1 python process that belongs to w15cpteam3,
#it means the server is down, it restarts the server
#checks every 5 seconds, if the server is up, it sleeps, if not restarts
pipe = None
while True:
        if (len(getPIDs("python")) == 1):
                cmd = "python main.py"
                output_file = open("./logs/.server_stdout", "a")
                pipe = runCommand(cmd.split(), blocking=False, output_file=output_file)
	sleep(5)
