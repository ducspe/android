import socket,re
from sys import exit

#gets the port number from the config file
port = 0
f = open(".config", "r")
for line in f:
	if re.search("port", line):
		port = int(line.split("=")[-1].strip())
		break
f.close()
#creates a client socket
#tries to connect to the given port at localhost
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
	client.connect(('',port))
except:
	#if connection fails, exits
	exit()
#if connection is successful
#sends the command 'exit' to the server to kill it
client.send("exit")
